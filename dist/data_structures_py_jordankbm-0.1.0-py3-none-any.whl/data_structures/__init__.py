from .array import Array_new
from .linked_lists import LinkedList
from .stack import Stack
from .trees import BinaryTree
from .queue import Queue